using UnityEngine;

public class SunMoviment : MonoBehaviour
{
    [SerializeField, Tooltip("The speed that object rotates at.")]
    private float _rotationSpeed = 1.0f;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // grab the currennt rotatation, increment it, and re-apply it.
        Vector3 newRotation = transform.eulerAngles;
        newRotation.x += (_rotationSpeed * Time.deltaTime);
        transform.eulerAngles = newRotation;

        // If the rotation goes beyond 360 degrees, reset it to 0
        if (newRotation.x >= 360.0f)
        {
            newRotation.x -= 360.0f;
            transform.eulerAngles = newRotation;
        }
    }
}
